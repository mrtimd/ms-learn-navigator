chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PAGE_VISIT") {
    const payload = message.payload;

    chrome.storage.local.get("navState", (data) => {
      const existing = data.navState || {};
      const { url, title } = payload;

      let course = existing.course || null;
      let path = existing.path || [];
      let progress = existing.progress || {};

      if (url.includes("/courses/")) {
        course = { title, url };
        path = [];
      } else {
        const last = path.at(-1);
        if (!last || last.url !== url) {
          path.push({ title, url });
        }
      }

      if (url.includes("/modules/")) {
        progress[url] = true;
      }

      const navState = {
        course,
        path,
        progress,
        lastVisited: url
      };

      console.log("✅ navState stored:", navState);
      chrome.storage.local.set({ navState });
    });
  }

  if (message.type === "MODULE_COMPLETE") {
    const { url } = message.payload;

    chrome.storage.local.get("navState", (data) => {
      const existing = data.navState || {};
      const progress = existing.progress || {};

      progress[url] = true;

      const updated = {
        ...existing,
        progress
      };

      console.log("✅ Module stored as complete:", url);

      chrome.storage.local.set({ navState: updated });
    });
  }
});